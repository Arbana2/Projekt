Package Diagram for Agolli System.
Included file: package_diagram_agolli.png